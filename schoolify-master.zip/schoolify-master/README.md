# Schoolify

## What is it?
Schoolify is a multitasking game that lets the user play up to four different minigames at once. Also, these games are closely related to the university life. Schoolify uses pygame as its main game engine.

Created in collaboration with Joshua Du, Stephen Hwang, Gary Chen, Junwen Jiang, Alice Peng
